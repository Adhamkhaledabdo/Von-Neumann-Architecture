
public class CAappException extends Exception{

    public CAappException(String x){
        super(x);
    }

}
