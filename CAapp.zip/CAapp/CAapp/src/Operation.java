public class Operation {
    private String name;
    private String mnemonic;
    private String type;
    private String format;

    public Operation(String name, String mnemonic, String type, String format) {
        this.name = name;
        this.mnemonic = mnemonic;
        this.type = type;
        this.format = format;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMnemonic() {
        return mnemonic;
    }

    public void setMnemonic(String mnemonic) {
        this.mnemonic = mnemonic;
    }

    public static int performOp(String mnemonic, int first, int imm, int second, int shamt) {


        if(shamt!=0000000000000 && second==0000) {
            switch(mnemonic) {
                case "SLL":
                    return first<<shamt;
                case "SRL":
                    return first>>>shamt;
                default:
                    return 0;
            }
        }
        else{
            if(imm!=000000000000000000 && second==0000) {
                switch (mnemonic) {
                    case "MULI":
                        return first * imm;
                    case "ADDI":
                        return first + imm;
                    case "ANDI":
                        return first & imm;
                    case "ORI":
                        return first | imm;
                    //case "BNE":
                    //  return first + second;
                    case "J":
                        return first = second;
                    // case "LW":
                    //  return first + second;
                    //case "SW":
                    //  return first + second;
                    default:
                        return 0;
                }
            }
            else{

                switch (mnemonic) {
                    case "ADD":
                        return first + second;
                    case "SUB":
                        return first - second;
                    default:
                        return 0;
                }
            }
        }
    }
}


