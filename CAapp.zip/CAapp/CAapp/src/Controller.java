import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Vector;

public class Controller {

    private ArrayList<String[]> Parsed_Instructions;

    public Controller(){
        this.Parsed_Instructions = new ArrayList<String[]>();
        ReadTxtFile("CAapp/src/CAins.txt"); // i will put text file name where have assembly code
    }

    private void ReadTxtFile(String Filename){
        try {
                BufferedReader reader = new BufferedReader(new FileReader(Filename));
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] words = line.split(" ");
                    this.Parsed_Instructions.add(words);
                    
                }
                reader.close();
        } catch (IOException e) {
                System.err.println("Error reading file: " + e.getMessage());
                System.exit(1);
        }
    }
    


    

    public ArrayList<String[]> getParsed_Instructions() {
        return Parsed_Instructions;
    }

    public void setParsed_Instructions( ArrayList<String[]> parsed_Instructions) {
        Parsed_Instructions = parsed_Instructions;
    }

    
}
