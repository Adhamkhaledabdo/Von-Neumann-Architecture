import com.sun.jdi.IntegerType;

import java.lang.reflect.Array;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;


public class CPU {

	String[] memory;

	Hashtable<String,String> opcode_hash;
	Register pc;
	Register R0;
	private Hashtable<String,String> RegisterFile;
	private ArrayList<Register> Countainer_register;

	boolean FlagForBranch = false;
	boolean FlagForJump = false;

	public CPU() throws CAappException{
		this.Countainer_register = new ArrayList<Register>();
		memory = new String[2048];
		this.opcode_hash = new Hashtable<String,String>();

		this.RegisterFile = new Hashtable<String,String>();
		pc = new Register("PC" , 0);
		R0 = new Register("R0" , 0);
		this.Countainer_register.add(R0);
		this.RegisterFile.put("R0","00000");
		for(int i=1;i<=31;i++){
			// create 31 register
			Register register_temp = new Register("R"+i, 0);
			String x = ConvertIntoBinary(i, 5);
			this.RegisterFile.put(register_temp.getName(), x);
			this.Countainer_register.add(register_temp);
		}


		opcode_hash.put("ADD","0000");
		opcode_hash.put("SUB","0001");
		opcode_hash.put("MULI","0010");
		opcode_hash.put("ADDI","0011");
		opcode_hash.put("BNE","0100");
		opcode_hash.put("ANDI","0101");
		opcode_hash.put("ORI","0110");
		opcode_hash.put("J","0111");
		opcode_hash.put("SLL","1000");
		opcode_hash.put("SRL","1001");
		opcode_hash.put("LW","1010");
		opcode_hash.put("SW","1011");

		Controller control = new Controller();


		for(int i=0;i<control.getParsed_Instructions().size();i++) {

			String op_bit = opcode_hash.get((control.getParsed_Instructions().get(i))[0]);
			if(op_bit == null) {
				throw new CAappException("this opcode is not found");
			}
			//jump instruction
			if(op_bit.equals("0111")) {
				op_bit +=  ConvertIntoBinary(binaryToSignedInt((control.getParsed_Instructions().get(i))[1]), 28);
			}
			// add and sub
			else if(op_bit.equals("0000") || op_bit.equals("0001")) {
				op_bit += this.RegisterFile.get((control.getParsed_Instructions().get(i))[1]);
				op_bit += this.RegisterFile.get((control.getParsed_Instructions().get(i))[2]);
				op_bit += this.RegisterFile.get((control.getParsed_Instructions().get(i))[3]);
				op_bit += "0000000000000";

			}
			//shift logical left and right
			else if(op_bit.equals("1000") || op_bit.equals("1001")) {
				op_bit += this.RegisterFile.get((control.getParsed_Instructions().get(i))[1]);
				op_bit += this.RegisterFile.get((control.getParsed_Instructions().get(i))[2]);
				op_bit +=  "00000";
				op_bit += ConvertIntoBinary(binaryToSignedInt((control.getParsed_Instructions().get(i))[3]), 13);
			}

			// immediate
			else {
				op_bit += this.RegisterFile.get((control.getParsed_Instructions().get(i))[1]);
				op_bit += this.RegisterFile.get((control.getParsed_Instructions().get(i))[2]);

				int decimal = binaryToDecimal((String)((control.getParsed_Instructions().get(i))[3]));
			
				int dec = Integer.parseInt((String)((control.getParsed_Instructions().get(i))[3]));
	
				op_bit +=  ConvertIntoBinary(dec , 18);
				System.out.println("anaa mwgudd henaaa     " + ConvertIntoBinary(dec , 18) );
				System.out.println( " op_bittt :-----   "+op_bit);
			}
			memory[i] = op_bit;
		}


		pipelining();

	}




	public void pipelining() throws CAappException {
		Boolean fetch = false;
		Boolean decodefirst = false;
		Boolean decodesecond = false;
		Boolean executefirst = false;
		Boolean executesecond = false;
		Boolean mem = false;
		Boolean writeback = false;
		Boolean addition1 = false;
		Boolean addition2 = false;
		int instruction_count =1;
		String ins=null;
		ArrayList<Integer> insDecoded = new ArrayList<>();
		ArrayList<Integer> insDelayedDecoded = new ArrayList<>();
		int exec= 0;
		int Dest = 0;
		int numberOfInstructions = numberOfInstructions();
		int numberOfCycles = numberOfCycles(numberOfInstructions);

		if(numberOfInstructions<3) {

			if (numberOfInstructions == 1) {
				int i;
				for (i = 1; i <= numberOfCycles; i++) {
					if (!fetch) {
						ins = Fetch();
						fetch = true;
						continue;
					}
					if (!decodefirst) {
						doNothing();
						decodefirst = true;
						continue;
					}
					if (!decodesecond) {
						insDecoded = decode(ins);
						decodesecond = true;
						continue;
					}
					if (!executefirst) {
						doNothing();
						executefirst = true;
						continue;
					}
					if (!executesecond) {
						exec = execute(insDecoded);
						executesecond = true;
						continue;
					}
					if (!mem) {
						Dest = memoryAccess(insDecoded, exec);
						mem = true;
						continue;
					}
					if (!writeback) {
						WriteBack(insDecoded, Dest);
						writeback = true;
						continue;
					}
				}
			} else {
				if (numberOfInstructions == 2) {
					int i;
					for (i = 1; i <= numberOfCycles; i++) {
						if (!fetch) {
							ins = Fetch();
							fetch = true;
							continue;
						}
						if (!decodefirst) {
							doNothing();
							decodefirst = true;
							continue;
						}
						if (!decodesecond) {
							insDecoded = decode(ins);
							ins = Fetch();
							decodesecond = true;
							continue;
						}
						if (!executefirst) {
							doNothing();
							executefirst = true;
							continue;
						}
						if (!executesecond) {
							exec = execute(insDecoded);
							insDelayedDecoded = insDecoded;
							insDecoded = decode(ins);
							executesecond = true;
							continue;
						}
						if (!mem) {
							Dest = memoryAccess(insDelayedDecoded, exec);
							mem = true;
							continue;
						}
						if (!writeback) {
							WriteBack(insDelayedDecoded, Dest);
							exec = execute(insDecoded);
							writeback = true;
							continue;
						}
						if (!addition1) {
							Dest = memoryAccess(insDecoded, exec);
							addition1 = true;
							continue;
						}
						if (!addition2) {
							WriteBack(insDecoded, Dest);
							addition2 = true;
							continue;
						}
					}
				}

			}


		}

		else{
			int i;
			int j=0;
			for(i=1;i<=numberOfCycles;i++) {

				if (!fetch) {
					System.out.println("---------------------------------feeffe ------------------------------" + this.pc.getValue() + "   " + numberOfCycles + "    " + i);
					ins = Fetch();
					fetch = true;
					//continue;
				}
				if (!decodefirst) {
					System.out.println("------------------------------------sisi---------------------------");
					//doNothing();
					decodefirst = true;
					//continue;
				}
				if (!decodesecond) {
					System.out.println("----------------------------------fefe-----------------------------");
					insDecoded = decode(ins);
					ins = Fetch();
					decodesecond = true;
					//continue;
				}
				if (!executefirst) {
					System.out.println("----------------------------------execee-----------------------------");
					//doNothing();
					executefirst = true;
					//continue;
				}
				if (!executesecond) {
					System.out.println("-------------------------------lililili--------------------------------");
					exec = execute(insDecoded);
					insDelayedDecoded = insDecoded;
					if( insDelayedDecoded.get(0)==4 || insDelayedDecoded.get(0)==7 ){
						if(this.FlagForBranch || this.FlagForJump){
							i+=2;
							System.out.println("2x NOP");
							fetch = false;
							decodefirst = false;
							decodesecond = false;
							executefirst = false;
							this.FlagForBranch = false;
							this.FlagForJump = false;
						}
					}
					insDecoded = decode(ins);
					executesecond = true;
					ins = Fetch();
					continue;
				}
				if (!mem) {
					System.out.println("---------------------------mememe------------------------------------");
					Dest = memoryAccess(insDelayedDecoded, exec);
					mem = true;
					writeback = false;
					//continue;
				}
				if (!writeback) {
					System.out.println("---------------------------------wwwwww------------------------------");
					WriteBack(insDelayedDecoded, Dest);
					System.out.println("memem " + this.pc.getValue());
					exec = execute(insDecoded);
					System.out.println("memem " + this.pc.getValue() + "    " + exec);
					insDelayedDecoded = insDecoded;
					if( insDelayedDecoded.get(0)==4 || insDelayedDecoded.get(0)==7 ){
						if(this.FlagForBranch || this.FlagForJump){
							//System.out.println("lolo ");
							i+=2;
							fetch = false;
							decodefirst = false;
							decodesecond = false;
							executefirst = false;
							executesecond = false;
							this.FlagForBranch = false;
							this.FlagForJump = false;
							//System.out.println("lolo " + fetch);
							this.pc.setValue(exec);
						}
					}
					insDecoded = decode(ins);
					//System.out.println("hahahah :-- " +this.pc.getValue() + " mem pos :-- " + memory[this.pc.getValue()]);
					System.out.println(fetch);
					if (memory[this.pc.getValue()] == null && fetch) {
						j = i;
						break;
					}
					//System.out.println("hahahah :-- " + fetch);
					if(fetch != false) {
						ins = Fetch();
					}
					writeback = true;
					mem = false;
					continue;
				}

			}

				boolean flag2 = false;
				boolean flag3 = false;
				boolean flag4 = false;
				boolean flag5 = false;

				while (j <= numberOfCycles) {
					//System.out.print("opppaaa");

					if (!flag2) {
						System.out.println("---------------------------------------------------------------");
						Dest = memoryAccess(insDelayedDecoded,exec);
						flag2 = true;
						continue;
					}
					if (!flag3) {
						System.out.println("---------------------------------------------------------------");
						WriteBack(insDelayedDecoded, Dest);
						exec = execute(insDecoded);
						flag3 = true;
						continue;
					}
					if (!flag4) {
						System.out.println("---------------------------------------------------------------");
						Dest = memoryAccess(insDecoded,exec);
						flag4 = true;
						continue;
					}
					if (!flag5) {
						System.out.println("---------------------------------------------------------------");
						WriteBack(insDecoded, Dest);
						flag5 = true;
						continue;
					}
					j++;

				}
			}
		}


	public int numberOfInstructions(){
		int res = 0;
		for(int i=0; i<memory.length/2 ; i++){
			if(memory[i]!= null){
				res += 1;
			}
		}
		return res;
	}
	public static int numberOfCycles (int numberOfInstructions ){
		return (7+((numberOfInstructions-1)*2));
	}

	public void doNothing(){
		//NO Operation
	}


	public String[] getMemory() {
		return memory;
	}

	public void setMemory(String[] memory) {
		this.memory = memory;
	}

	/*public String ConvertIntoBinary(int number, int numBits) {
		// Determine the sign of the number
		boolean isNegative = number < 0;

		// Get the absolute value of the number
		int absValue = Math.abs(number);

		// Calculate the maximum representable value for the given number of bits
		int maxValue = (1 << (numBits - 1)) - 1;

		// Check if the number exceeds the maximum representable value
		if (absValue > maxValue) {
			// Handle the out-of-range case based on the desired behavior
			if (isNegative) {
				absValue = maxValue;  // Set to the maximum negative value
			} else {
				absValue = maxValue;  // Set to the maximum positive value
			}
		}

		// Create the binary representation with the specified number of bits
		StringBuilder binaryRepresentation = new StringBuilder();

		// Build the binary representation from the most significant bit to the least significant bit
		for (int i = numBits - 1; i >= 0; i--) {
			int bitValue = (absValue >> i) & 1;
			binaryRepresentation.append(bitValue);
		}

		// Handle negative numbers using two's complement
		if (isNegative) {
			binaryRepresentation = performTwosComplement(binaryRepresentation);
		}

		return binaryRepresentation.toString();
	}

	private StringBuilder performTwosComplement(StringBuilder binaryRepresentation) {
		boolean foundFirstOne = false;

		// Invert all the bits starting from the least significant bit
		for (int i = binaryRepresentation.length() - 1; i >= 0; i--) {
			char bit = binaryRepresentation.charAt(i);
			if (bit == '0') {
				binaryRepresentation.setCharAt(i, '1');
			} else {
				binaryRepresentation.setCharAt(i, '0');
				foundFirstOne = true;
			}
		}

		// Add an extra most significant bit if necessary
		if (!foundFirstOne) {
			binaryRepresentation.insert(0, '1');
		}

		return binaryRepresentation;
	}*/
	
	public static String ConvertIntoBinary(int number, int numBits) {
        // Determine the sign of the number
        boolean isNegative = number < 0;

        // Get the absolute value of the number
        int absValue = Math.abs(number);

        // Calculate the maximum representable value for the given number of bits
        int maxValue = (1 << (numBits - 1)) - 1;

        // Check if the number exceeds the maximum representable value
        if (absValue > maxValue) {
            // Handle the out-of-range case based on the desired behavior
            if (isNegative) {
                absValue = maxValue;  // Set to the maximum negative value
            } else {
                absValue = maxValue;  // Set to the maximum positive value
            }
        }

        // Create the binary representation with the specified number of bits
        StringBuilder binaryRepresentation = new StringBuilder();

        // Build the binary representation from the most significant bit to the least significant bit
        for (int i = numBits - 1; i >= 0; i--) {
            int bitValue = (absValue >> i) & 1;
            binaryRepresentation.append(bitValue);
        }

        // Handle negative numbers using two's complement
        if (isNegative) {
            binaryRepresentation = performTwosComplement(binaryRepresentation, numBits);
        }

        return binaryRepresentation.toString();
    }

    public static StringBuilder performTwosComplement(StringBuilder binary, int numBits) {
        // Flip the bits
        for (int i = 0; i < numBits; i++) {
            if (binary.charAt(i) == '0') {
                binary.setCharAt(i, '1');
            } else {
                binary.setCharAt(i, '0');
            }
        }

        // Add 1 to the flipped bits
        boolean carry = true;
        for (int i = numBits - 1; i >= 0; i--) {
            if (carry) {
                if (binary.charAt(i) == '0') {
                    binary.setCharAt(i, '1');
                    carry = false;
                } else {
                    binary.setCharAt(i, '0');
                    carry = true;
                }
            }
        }

        return binary;
    }


	public String Fetch(){
		String instruction = memory[pc.getValue()];
		System.out.println("Instruction '"+instruction+"' is being fetched");
		pc.setValue(pc.getValue()+1);
		return instruction;
	}
	public ArrayList<Integer> decode(String instruction) throws CAappException {

		ArrayList<Integer> result = new ArrayList<>();


		String OpCode = instruction.substring(0, 4);
		int OpCodeINT = ConvertOpcodeIntoInt(OpCode);
		result.add(OpCodeINT);

		// r1 , r2, r3 ---> register instruction
		if(OpCodeINT == 0 || OpCodeINT == 1 ) {
			String Register_R1 = instruction.substring(4, 9);
			int First_Register = getIndexOfRegister(Register_R1); //  if R1 which will return 1
			String Register_R2 = instruction.substring(9, 14);
			int Second_Register = getIndexOfRegister(Register_R2); // second register
			String Register_R3 = instruction.substring(14, 19);
			int third_Register = getIndexOfRegister(Register_R3); // third register


			result.add(First_Register);
			result.add(Second_Register);
			result.add(third_Register);
			String temp1 = getKeyFromHashtable(this.RegisterFile,Register_R1);
			String temp2 = getKeyFromHashtable(this.RegisterFile,Register_R2);
			String temp3 = getKeyFromHashtable(this.RegisterFile,Register_R3);

				System.out.println("The "+instruction+" has Opcode: "+result.get(0)+"," +
						" first operand: "+result.get(2)+"-> "+temp2+"," +
						" second operand: "+result.get(3)+"-> "+temp3+"," +
						"  output: "+result.get(1)+"-> "+temp1);
				// return with array with these integers
		}
		// immediate instruction
		else if(OpCodeINT == 2 || OpCodeINT == 3 || OpCodeINT == 5 || OpCodeINT == 6 || OpCodeINT == 10 || OpCodeINT == 11) {
			String Register_R1 = instruction.substring(4, 9);
			int First_Register = getIndexOfRegister(Register_R1); //  if R1 which will return 1
			String Register_R2 = instruction.substring(9, 14);
			int Second_Register = getIndexOfRegister(Register_R2); // second register
			String Immediate = instruction.substring(14, 32);
			int ImmediateInt = binaryToSignedInt(Immediate); // immediate
			//System.out.print("hashasahsbcabhsa a7a7aaa :---- " + instruction);
			System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&"+ Immediate +"&&&&&&&&&&&&&&&&&&&&&&");

			//  return with array with these integers
			result.add(First_Register);
			result.add(Second_Register);
			result.add(ImmediateInt);

			String temp1 = getKeyFromHashtable(this.RegisterFile,Register_R1);
			String temp2 = getKeyFromHashtable(this.RegisterFile,Register_R2);

			if(OpCodeINT==2 || OpCodeINT==3 || OpCodeINT==5 || OpCodeINT==6) {
				System.out.println("The " + instruction + " has Opcode: " + result.get(0) + "," +
						" first operand: " + result.get(2) + "-> " + temp2 + "," +
						" second operand: Immediate value -> " + ImmediateInt + "," +
						" output: " + result.get(1) + "-> " + temp1);
			}
			else {
					if(OpCodeINT==10){

						System.out.println("The " + instruction + " has Opcode: " + result.get(0) + "," +
								" first operand: " + result.get(2) + "-> " + temp2 + "," +
								" second operand: Immediate value -> " + ImmediateInt + "," +
								"--> MEM[ "+temp2+" + "+ImmediateInt+" ]" + " output: " + result.get(1) + "-> " + temp1);
					}
					else {

						System.out.println("The " + instruction + " has Opcode: " + result.get(0) + "," +
								" first operand: " + result.get(1) + "-> " + temp1 + "," +
								" Immediate value -> " + ImmediateInt + "," +
								"--> Ouput : MEM[ "+temp2+" + "+ImmediateInt+" ]");
					}
			}

		}
		// shifting
		else if(OpCodeINT == 8 || OpCodeINT == 9) {
			String Register_R1 = instruction.substring(4, 9);
			int First_Register = getIndexOfRegister(Register_R1); //  if R1 which will return 1
			String Register_R2 = instruction.substring(9, 14);
			int Second_Register = getIndexOfRegister(Register_R2); // second register
			String Shamt = instruction.substring(19,32);
			int ShamtINT = binaryToSignedInt(Shamt);// for shifting

			//  return with array with these integers
			result.add(First_Register);
			result.add(Second_Register);
			result.add(ShamtINT);

			String temp1 = getKeyFromHashtable(this.RegisterFile,Register_R1);
			String temp2 = getKeyFromHashtable(this.RegisterFile,Register_R2);

			System.out.println("The "+instruction+" has Opcode: "+result.get(0)+"," +
					" first operand: "+result.get(2)+"-> "+temp2+"," +
					" second operand: Shift amount -> "+ShamtINT+"," +
					" output: "+result.get(1)+"-> "+temp1);

		}

		// for BNE
		else {
			if(OpCodeINT==4){

				String Register_R1 = instruction.substring(4, 9);
				int First_Register = getIndexOfRegister(Register_R1); //  if R1 which will return 1
				String Register_R2 = instruction.substring(9, 14);
				int Second_Register = getIndexOfRegister(Register_R2); // second register
				String Immediate = instruction.substring(14, 32);
				int ImmediateInt = binaryToDecimal(Immediate); // immediate
				//  return with array with these integers
				result.add(First_Register);
				result.add(Second_Register);
				result.add(ImmediateInt);

				String temp1 = getKeyFromHashtable(this.RegisterFile,Register_R1);
				String temp2 = getKeyFromHashtable(this.RegisterFile,Register_R2);

				System.out.println("The "+instruction+" has Opcode: "+result.get(0)+"," +
						" first operand: "+result.get(1)+" -> "+temp1+"," +
						" second operand: "+ result.get(2)+" -> "+ temp2+","+
						" third operand: Immediate value -> "+ImmediateInt);

			}
			//for Jump
			else {
				String JumpingAddress = instruction.substring(4, 32);
				int JumpingAddressINT = binaryToSignedInt(JumpingAddress);
				result.add(JumpingAddressINT);

				System.out.println("The "+instruction+" has Opcode: "+result.get(0)+"," + "The Address: "+ JumpingAddressINT);
			}
		}
		return result;
	}

	public int execute(ArrayList<Integer> result) throws CAappException{
		int opcode = result.get(0);

		// add
		int resulttoWriteBack=0; // will move to write back
		Register r1 = null;
		Register r2 =null;
		// i want to handle that in some casses index 3 is not register for all 
		Register r3 = null;

		switch (opcode) {
			case 0: r1 = this.Countainer_register.get(result.get(1));
				r2 = this.Countainer_register.get(result.get(2));
				r3 = this.Countainer_register.get(result.get(3));
				resulttoWriteBack = r2.getValue() + r3.getValue();
				System.out.println("For instruction "+ result +" the inputs are "+ r2.getValue()+" and "+r3.getValue()+", the output is "+ (r2.getValue()+r3.getValue()));
				return resulttoWriteBack;
			//r1.setValue(r2.getValue() + r3.getValue());
			case 1: r1 = this.Countainer_register.get(result.get(1));
				r2 = this.Countainer_register.get(result.get(2));
				r3 = this.Countainer_register.get(result.get(3));
				resulttoWriteBack = r2.getValue() - r3.getValue();
				System.out.println("For instruction "+ result +" the inputs are "+ r2.getValue()+" and "+r3.getValue()+", the output is "+ (r2.getValue()-r3.getValue()));
				return resulttoWriteBack;
			//r1.setValue(r2.getValue() - r3.getValue());
			case 2: r1 = this.Countainer_register.get(result.get(1));
				r2 = this.Countainer_register.get(result.get(2));
				resulttoWriteBack = r2.getValue() * result.get(3);
				System.out.println("For instruction "+ result +" the inputs are "+ r2.getValue()+" and "+result.get(3)+", the output is "+ (r2.getValue()*result.get(3)));
				return resulttoWriteBack;
			//r1.setValue(r2.getValue() * result.get(3));
			case 3:
				r1 = this.Countainer_register.get(result.get(1));
				r2 = this.Countainer_register.get(result.get(2));
				resulttoWriteBack = r2.getValue() + result.get(3);
				System.out.println("in ADDI :--- " + r1 +" " + r2 + " " + result.get(3));
				System.out.println("For instruction "+ result +" the inputs are "+ r2.getValue()+" and "+result.get(3)+", the output is "+ (r2.getValue()+result.get(3)));
				return resulttoWriteBack;
			//r1.setValue(r2.getValue() + result.get(3));
			case 4:
				r1 = this.Countainer_register.get(result.get(1));
				r2 = this.Countainer_register.get(result.get(2));
				if(r1.getValue()!= r2.getValue()) {
					resulttoWriteBack = this.pc.getValue()-1+result.get(3);
					this.FlagForBranch = true;
					System.out.println("For instruction "+ result +" the inputs are "+ r1.getValue()+", "+r2.getValue()+" and "+ result.get(3)+" , the PC will change to "+ resulttoWriteBack );
					return resulttoWriteBack;
				}

			case 5: r1 = this.Countainer_register.get(result.get(1));
				r2 = this.Countainer_register.get(result.get(2));
				resulttoWriteBack = r2.getValue() & result.get(3);
				System.out.println("For instruction "+ result +" the inputs are "+ r2.getValue()+" and "+result.get(3)+", the output is "+ (r2.getValue()&result.get(3)));
				return resulttoWriteBack;
			//r1.setValue(r2.getValue() & result.get(3));
			case 6: r1 = this.Countainer_register.get(result.get(1));
				r2 = this.Countainer_register.get(result.get(2));
				resulttoWriteBack = r2.getValue() | result.get(3);
				System.out.println("For instruction "+ result +" the inputs are "+ r2.getValue()+" and "+result.get(3)+", the output is "+ (r2.getValue()|result.get(3)));
				return resulttoWriteBack;
			//r1.setValue(r2.getValue() | result.get(3));
			case 7: String pcInBinary = ConvertIntoBinary(this.pc.getValue(),32);
				String pcfrom28to31 = pcInBinary.substring(0,4);
				String x = pcfrom28to31 + ConvertIntoBinary(result.get(1),28);
				int  pcfrom28to31int = binaryToSignedInt(x);
				resulttoWriteBack = pcfrom28to31int;
				if(resulttoWriteBack < 0) {
					throw new CAappException("PC can not be negtive");
				}
				else if(resulttoWriteBack < this.pc.getValue()) {
					int diff = this.pc.getValue() - resulttoWriteBack;
					int resultCycle = 7 + ((diff-1)*2);
					
				}
				System.out.println("For instruction "+ result +" the input is "+result.get(1)+" , the PC will change to "+ resulttoWriteBack );
				this.FlagForJump = true;
				return resulttoWriteBack;
			//this.pc.setValue(pcfrom28to31int); // jump
			case 8: r1 = this.Countainer_register.get(result.get(1));
				r2 = this.Countainer_register.get(result.get(2));
				resulttoWriteBack = r2.getValue() << result.get(3);
				System.out.println("For instruction " + result +" the inputs are "+ r2.getValue()+" and "+result.get(3)+", the output is "+ (r2.getValue()<<result.get(3)));
				return resulttoWriteBack;
			//r1.setValue(r2.getValue() << result.get(3));
			case 9:r1 = this.Countainer_register.get(result.get(1));
				r2 = this.Countainer_register.get(result.get(2));
				resulttoWriteBack = r2.getValue() >>> result.get(3);
				System.out.println("For instruction "+ result +" the inputs are "+ r2.getValue()+" and "+result.get(3)+", the output is "+ (r2.getValue()>>>result.get(3)));
				return resulttoWriteBack;
			//r1.setValue(r2.getValue() >>> result.get(3));
			case 10: return -1;
			case 11: return -1;
			default: throw new CAappException("this is invalid input");
		}



	}
	public int memoryAccess(ArrayList<Integer> result, int resulttoWriteBack) {

		if(resulttoWriteBack==-1) {
			int opcode = result.get(0);
			// add
			Register r1 = null;
			Register r2 = null;
			Register r3 = null;
			if (opcode == 10) {
				r1 = this.Countainer_register.get(result.get(1));
				r2 = this.Countainer_register.get(result.get(2));
				String data = this.memory[1024 + r2.getValue() + result.get(3)];
				int dataINT = binaryToSignedInt(data);
				resulttoWriteBack = dataINT;
				System.out.println("The Address: "+ (1024 + r2.getValue() + result.get(3)));
				System.out.println("The data need to be Loaded: "+ dataINT);
			}
			// for store the word not need to write back
			else {
				r1 = this.Countainer_register.get(result.get(1));
				r2 = this.Countainer_register.get(result.get(2));
				this.memory[1024 + r2.getValue() + result.get(3)] = ConvertIntoBinary(r1.getValue(), 32);
				System.out.println("The Address: "+ (1024 + r2.getValue() + result.get(3)));
				System.out.println("Memory["+ (1024 + r2.getValue() + result.get(3)) +"]: "+ this.memory[1024 + r2.getValue() + result.get(3)]);
			}
		}
		return resulttoWriteBack;
	}

	public void WriteBack(ArrayList<Integer> result , int resulttoWriteBack) throws CAappException {
		int opcode = result.get(0);
		System.out.print(opcode);
		if(opcode != 11) {
			if(opcode == 4 || opcode == 7) {
				System.out.print(resulttoWriteBack);
				this.pc.setValue(resulttoWriteBack);
				System.out.println("The PC has changed to: "+ resulttoWriteBack);
				System.out.println("The R0 is still: "+ this.R0.getValue());
			}
			else {
				(this.Countainer_register.get(result.get(1))).setValue(resulttoWriteBack);
				System.out.println("The "+ (this.Countainer_register.get(result.get(1))).getName() +" has changed to: " + resulttoWriteBack);
				System.out.println("The R0 is still: "+ this.R0.getValue());
			}
		}
	}

	public int getIndexOfRegister(String x) throws CAappException {
		String NameOfRegister = "";
		if (x == "00000") {
			return 0;
		}

		for (Map.Entry<String, String> entry : this.RegisterFile.entrySet()) {
			if (entry.getValue().equals(x)) {
				NameOfRegister = entry.getKey();
				break;
			}
		}
		if(NameOfRegister == "") {
			throw new CAappException("this is invalid input");
		}
		String result = NameOfRegister.substring(1, 2);
		int ResultInt = Integer.parseInt(result);
		return ResultInt;


	}

	public int ConvertOpcodeIntoInt(String x) throws CAappException {
		switch (x){
			case "0000": return 0; // add
			case "0001": return 1; // sub
			case "0010": return 2; // multi
			case "0011": return 3; // addi
			case "0100": return 4; // bne
			case "0101": return 5; // andi
			case "0110": return 6; // ori
			case "0111": return 7; // jump instruction
			case "1000": return 8; // shift logical left
			case "1001": return 9; // shift right logical
			case "1010": return 10; // load word
			case "1011": return 11; // store word
			default : throw new CAappException("this is invalid input");
		}
	}



	public static String getKeyFromHashtable(Hashtable<String, String> hashtable, String value) {
		// Iterate over the entries in the Hashtable
		for (Map.Entry<String, String> entry : hashtable.entrySet()) {
			// Check if the value matches
			if (entry.getValue().equals(value)) {
				// Return the corresponding key
				return entry.getKey();
			}
		}

		// Value not found in the Hashtable
		return null; // or you can throw an exception or return a default value
	}


	public static int binaryToDecimal(String binaryString) {
		// Check if the number is negative
		boolean isNegative = binaryString.charAt(0) == '1';

		// Perform two's complement if the number is negative
		if (isNegative) {
			binaryString = performTwosComplement(binaryString);
		}

		// Convert binary to decimal
		int decimal = 0;
		int power = binaryString.length() - 1;
		for (int i = 0; i < binaryString.length(); i++) {
			int bit = binaryString.charAt(i) - '0';
			decimal += bit * (1 << power);
			power--;
		}

		// Negate the decimal value if the number was originally negative
		if (isNegative) {
			decimal = -decimal;
		}

		return decimal;
	}

	private static String performTwosComplement(String binaryString) {
		StringBuilder complement = new StringBuilder();

		// Invert all the bits
		for (int i = 0; i < binaryString.length(); i++) {
			char bit = binaryString.charAt(i);
			complement.append(bit == '0' ? '1' : '0');
		}

		// Add 1 to the result
		int carry = 1;
		for (int i = complement.length() - 1; i >= 0; i--) {
			if (carry == 0) {
				break;
			}

			char bit = complement.charAt(i);
			if (bit == '0') {
				complement.setCharAt(i, '1');
				carry = 0;
			} else {
				complement.setCharAt(i, '0');
			}
		}

		return complement.toString();
	}
	
	public static int binaryToSignedInt(String binary) {
        int length = binary.length();
        int value = Integer.parseInt(binary, 2);
        
        // Handle negative numbers using two's complement
        if (binary.charAt(0) == '1') {
            value -= (1 << length);
        }
        
        return value;
    }






	public static void main(String[] args) throws CAappException {
		CPU x = new CPU();
		int xint  = -5;
		System.out.print("----------------- after allll ----------------------");
		String xs = x.ConvertIntoBinary(xint,18);
		System.out.println(xs);
		System.out.println(binaryToSignedInt(xs));
		System.out.println(Integer.parseInt("-5"));
		System.out.println(xs);
	}


}
