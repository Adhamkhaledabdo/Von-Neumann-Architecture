public class Register {

    private String name;
    private int value;
    public Register(String name, int value){
        this.name = name;
        this.value = value;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getValue() {
        return value;
    }
    public void setValue(int value) {
        this.value = value;
    }

    public int GetSecondName(String name) throws CAappException{
        if(name.length()>2){
            throw new CAappException("this is invalid input");
        }
        else{
             char x = name.charAt(1);
             return Character.getNumericValue(x);
        }
    }

    
}
// each register have only one instruction 